# LAN Backup - Companion Server Installer (Windows)
#
# What this script does:
#   1. Checks whether Node.js is installed; installs it if not.
#   2. Starts the companion server.
#   3. On first run the server generates a secure token automatically,
#      saves it to .env, and prints it for you to copy into the app.
#
# How to run:
#   Open PowerShell in this folder and run:
#   powershell.exe -ExecutionPolicy Bypass -File install.ps1
#
# Requirements: internet for the Bonjour helper (and Node.js if it must be installed)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host ""
Write-Host "=============================================="
Write-Host "   LAN Backup -- Server Setup (Windows)"
Write-Host "=============================================="
Write-Host ""

# -- Check / install Node.js --------------------------------------------------

function Refresh-NodePath {
    # Re-read Machine + User PATH from the registry and apply to this session
    $machinePath = [System.Environment]::GetEnvironmentVariable("PATH", "Machine")
    $userPath    = [System.Environment]::GetEnvironmentVariable("PATH", "User")
    $env:PATH    = "$machinePath;$userPath"

    # winget sometimes installs to a versioned sub-folder that isn't yet in the
    # registry PATH.  Probe the two most common locations and add them if needed.
    $candidates = @(
        "$env:ProgramFiles\nodejs",
        "${env:ProgramFiles(x86)}\nodejs",
        "$env:LOCALAPPDATA\Programs\nodejs"
    )
    foreach ($dir in $candidates) {
        if ((Test-Path "$dir\node.exe") -and ($env:PATH -notlike "*$dir*")) {
            $env:PATH = "$dir;$env:PATH"
        }
    }
}

function Install-NodeViaWinget {
    Write-Host "  Installing Node.js via winget..."
    # Use --source winget explicitly to avoid the msstore certificate error
    # (0x8a15005e) that occurs on some corporate / restricted networks.
    winget install OpenJS.NodeJS.LTS `
        --source winget `
        --accept-source-agreements `
        --accept-package-agreements `
        --silent
    Refresh-NodePath
}

function Install-NodeViaMsi {
    $version = "20.19.0"
    $arch = if ([System.Environment]::Is64BitOperatingSystem) { "x64" } else { "x86" }
    $url = "https://nodejs.org/dist/v$version/node-v$version-$arch.msi"
    $installer = "$env:TEMP\node-installer.msi"

    Write-Host "  Downloading Node.js $version from nodejs.org..."
    Invoke-WebRequest -Uri $url -OutFile $installer -UseBasicParsing

    Write-Host "  Installing (this may take a moment)..."
    Start-Process msiexec.exe -Wait -ArgumentList "/i `"$installer`" /quiet /norestart"
    Remove-Item $installer -Force

    Refresh-NodePath
}

$nodeFound = $null -ne (Get-Command node -ErrorAction SilentlyContinue)

if ($nodeFound) {
    $nodeVer = node --version
    Write-Host "  [OK] Node.js $nodeVer is already installed."
} else {
    Write-Host "  [!] Node.js not found - installing now..."
    Write-Host ""
    $wingetFound = $null -ne (Get-Command winget -ErrorAction SilentlyContinue)
    if ($wingetFound) {
        try {
            Install-NodeViaWinget
        } catch {
            Write-Host "  [!] winget failed, falling back to direct download..."
            Install-NodeViaMsi
        }
    } else {
        Install-NodeViaMsi
    }

    # Verify node is now reachable
    $nodeCmd = Get-Command node -ErrorAction SilentlyContinue
    if ($null -eq $nodeCmd) {
        Write-Host ""
        Write-Host "  [!] Node.js was installed but could not be found in PATH."
        Write-Host "      Please close this window, reopen PowerShell, and run install.ps1 again."
        Write-Host ""
        Read-Host "  Press Enter to close"
        exit 1
    }

    $nodeVer = node --version
    Write-Host ""
    Write-Host "  [OK] Node.js $nodeVer installed successfully."
}

# -- Create / refresh desktop shortcut ----------------------------------------
# The shortcut calls cmd.exe which resolves `node` from PATH at launch time,
# so it keeps working after Node.js is updated or reinstalled.
Write-Host "  Creating desktop shortcut..."
try {
    $WshShell  = New-Object -ComObject WScript.Shell
    $DesktopPath = [Environment]::GetFolderPath("Desktop")
    if ([string]::IsNullOrEmpty($DesktopPath)) {
        $DesktopPath = "$env:USERPROFILE\Desktop"
    }
    if (-not (Test-Path $DesktopPath)) {
        New-Item -ItemType Directory -Path $DesktopPath -Force | Out-Null
    }

    $LnkPath = Join-Path $DesktopPath "Start LAN Backup Server.lnk"
    $Shortcut  = $WshShell.CreateShortcut($LnkPath)
    $Shortcut.TargetPath       = "%SystemRoot%\system32\cmd.exe"
    $Shortcut.Arguments        = "/k `"cd /d `"$ScriptDir`" && node server.js`""
    $Shortcut.WorkingDirectory = $ScriptDir
    $Shortcut.Description      = "Start LAN Backup companion server"
    $Shortcut.IconLocation     = "$ScriptDir\lan-backup.ico,0"
    $Shortcut.Save()
    $LegacyShortcutPath = Join-Path $DesktopPath "LAN Backup Server.lnk"
    if (Test-Path $LegacyShortcutPath) {
        Remove-Item -LiteralPath $LegacyShortcutPath -Force -ErrorAction SilentlyContinue
    }
    Write-Host "  [OK] Shortcut created on Desktop."
} catch {
    Write-Host "  [!] Could not create shortcut: $_"
    Write-Host "      Run install.ps1 again to start the server manually."
}

Write-Host ""
Write-Host "-------------------------------------------------"
Write-Host "  Starting LAN Backup server..."
Write-Host "  Press Ctrl+C to stop."
Write-Host "-------------------------------------------------"
Write-Host ""

Push-Location $ScriptDir
node -e "require('bonjour-service')" 2>$null
$bonjourMissing = $LASTEXITCODE -ne 0
Pop-Location
if ((Test-Path "$ScriptDir\package.json") -and $bonjourMissing) {
    Write-Host "Installing LAN discovery support..."
    Push-Location $ScriptDir
    npm install --omit=dev --no-audit --no-fund
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Warning: Bonjour could not be installed; IP scanning will still work."
    }
    Pop-Location
}

node "$ScriptDir\server.js"

# Keep the window open if the user double-clicked the script
Write-Host ""
Write-Host "Server stopped. Press any key to close this window..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
